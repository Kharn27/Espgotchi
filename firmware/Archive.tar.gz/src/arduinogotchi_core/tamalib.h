#ifndef _ESPGOTCHI_TAMALIB_FWD_H_
#define _ESPGOTCHI_TAMALIB_FWD_H_

/*
 * Forward header : pour garder les #include "arduinogotchi_core/tamalib.h"
 * existants tout en utilisant directement le TamaLIB du sous-module.
 */

#include "../../lib/tamalib/tamalib.h"

#endif /* _ESPGOTCHI_TAMALIB_FWD_H_ */
